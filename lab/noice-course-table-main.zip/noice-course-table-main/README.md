# OOP2023F Homework Template Project

## Packages

### Required

* CMake >= 3.20
* Git
* C/C++ compiler

### Optional

* valgrind
* gcovr
* llvm (for llvm-cov if using clang)

For a more detailed explanation see https://hackmd.io/@OOP2023f/rk2-8cVCh
