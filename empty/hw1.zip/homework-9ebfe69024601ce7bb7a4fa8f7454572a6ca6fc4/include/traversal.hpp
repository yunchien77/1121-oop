#ifndef TRAVERSAL_HPP
#define TRAVERSAL_HPP

#include <cstddef>

bool traversal(std::size_t n, int arr[]);

#endif