#include <iostream>
#include <vector>

#include "../include/traversal.hpp"

bool traversal(std::size_t n, int arr[]) {
    /* 實作題目上的需求，若 arr 能夠被完整遍歷，輸出 Yes，否則輸出 No */
}
