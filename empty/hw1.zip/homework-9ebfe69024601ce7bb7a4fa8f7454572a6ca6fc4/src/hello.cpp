#include "hello.hpp"

std::string hello_world() {
    return "Hello World!";
}
