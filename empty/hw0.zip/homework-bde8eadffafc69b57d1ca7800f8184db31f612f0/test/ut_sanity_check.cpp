#include <gtest/gtest.h>

TEST(General, sanity_check) {
    EXPECT_TRUE(true);
}
