#ifndef HELLO_HPP
#define HELLO_HPP

#include <string>

std::string hello_world();

#endif
