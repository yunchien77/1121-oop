//
// Created by 黃漢軒 on 2023/12/18.
//

#ifndef OOP_EXPRESSTRAIN_HPP
#define OOP_EXPRESSTRAIN_HPP

#include "IReservable.hpp"
#include "Train.hpp"

class ExpressTrain {

};

#endif // OOP_EXPRESSTRAIN_HPP
