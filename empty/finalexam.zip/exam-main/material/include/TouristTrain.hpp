//
// Created by 黃漢軒 on 2023/12/18.
//

#ifndef OOP_TOURISTTRAIN_HPP
#define OOP_TOURISTTRAIN_HPP

#include "IReservable.hpp"
#include "Train.hpp"

class TouristTrain {

};

#endif // OOP_TOURISTTRAIN_HPP
