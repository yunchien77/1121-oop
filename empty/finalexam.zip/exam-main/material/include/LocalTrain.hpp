//
// Created by 黃漢軒 on 2023/12/18.
//

#ifndef OOP_LOCALTRAIN_HPP
#define OOP_LOCALTRAIN_HPP

#include "IReservable.hpp"
#include "Train.hpp"

class LocalTrain {
};

#endif // OOP_LOCALTRAIN_HPP
