//
// Created by 黃漢軒 on 2023/12/19.
//

#ifndef OOP_ENERGYINFO_HPP
#define OOP_ENERGYINFO_HPP

#include "ICalculable.hpp"

class EnergyInfo {

};

#endif // OOP_ENERGYINFO_HPP
