//
// Created by 黃漢軒 on 2023/12/19.
//

#ifndef OOP_TRAIN_HPP
#define OOP_TRAIN_HPP

#include "EnergyInfo.hpp"
#include "TrainInfo.hpp"
#include <memory>

class Train {
};

#endif // OOP_TRAIN_HPP
