#include "storage.hpp"

/* 根據 Header 來實作對應的 Function */