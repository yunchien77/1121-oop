#ifndef STORAGE_HPP
#define STORAGE_HPP

#include <string>
#include <vector>

class Storage {
public:
    /* 根據題目需求，定義成員與函式 */
    /* 見題目需求第三部分 */
};

#endif
