//
// Created by 黃漢軒 on 2023/12/7.
//

#include "MailSystem.h"

void MailSystem::AddOrdinaryMail(OrdinaryMail mail){
}

void MailSystem::AddDeliverableMail(std::shared_ptr<IDeliverable> deliverableMail){
}

void MailSystem::PostOrdinaryMail(){
}

DeliveryResult MailSystem::PostDeliverableMail(std::string date){

}

size_t MailSystem::GetOrdinaryMailSize(){
}

size_t MailSystem::GetDeliverableMailSize(){
}