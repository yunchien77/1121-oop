//
// Created by 黃漢軒 on 2023/12/7.
//

#include "MailInfo.h"
#include "OrdinaryMail.h"

OrdinaryMail::OrdinaryMail(MailInfo mailInfo) : mailInfo(mailInfo) {

}

MailInfo OrdinaryMail::GetMailInfo(){

}