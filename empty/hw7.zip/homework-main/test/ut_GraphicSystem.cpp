//
// Created by 黃漢軒 on 2023/12/22.
//

#include <gtest/gtest.h>

#include "Circle.hpp"
#include "GraphicSystem.hpp"
#include "IDrawable.hpp"
#include "Square.hpp"

// Implement tests here.