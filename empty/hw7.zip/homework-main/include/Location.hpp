//
// Created by 黃漢軒 on 2023/12/12.
//

#ifndef OOP_LOCATION_H
#define OOP_LOCATION_H

#include "Point.hpp"

class Location : public Point{
public:
    Location(int x, int y) : Point(x, y){

    }
};

#endif // OOP_LOCATION_H
