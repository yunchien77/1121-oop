//
// Created by 黃漢軒 on 2023/10/30.
//

#ifndef OOP_CRAFTBEER_H
#define OOP_CRAFTBEER_H

#include <string>

class CraftBeer {
private:
    std::string type = "Beer";
public:
    std::string GetType();
};

#endif // OOP_CRAFTBEER_H
