//
// Created by 黃漢軒 on 2023/10/30.
//

#ifndef OOP_WILDFIRE_H
#define OOP_WILDFIRE_H

#include <string>

class Wildfire {
private:
    std::string type = "Cocktail";
public:
    std::string GetType();
};

#endif // OOP_WILDFIRE_H
