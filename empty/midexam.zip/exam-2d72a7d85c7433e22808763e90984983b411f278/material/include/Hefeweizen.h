//
// Created by 黃漢軒 on 2023/10/30.
//

#ifndef OOP_HEFEWEIZEN_H
#define OOP_HEFEWEIZEN_H

#include <string>

class Hefeweizen {
private:
    std::string type = "Beer";
public:
    std::string GetType();
};

#endif // OOP_HEFEWEIZEN_H
