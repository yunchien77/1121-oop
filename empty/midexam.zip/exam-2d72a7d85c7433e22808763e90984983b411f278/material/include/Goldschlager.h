//
// Created by 黃漢軒 on 2023/10/30.
//

#ifndef OOP_GOLDSCHLAGER_H
#define OOP_GOLDSCHLAGER_H

#include <string>

class Goldschlager {
private:
    std::string type = "Shot";
public:
    std::string GetType();
};

#endif // OOP_GOLDSCHLAGER_H
