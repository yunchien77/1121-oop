//
// Created by 黃漢軒 on 2023/10/30.
//

#include <string>

#include "Margarita.h"

std::string Margarita::GetType(){
    return this->type;
}