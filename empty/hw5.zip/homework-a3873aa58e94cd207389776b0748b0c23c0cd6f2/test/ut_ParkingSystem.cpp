//
// Created by 黃漢軒 on 2023/11/20.
//

#include <gtest/gtest.h>

#include "Car.hpp"
#include "ElectricCar.hpp"
#include "Motorcycle.hpp"
#include "ParkingSystem.hpp"

// Add tests here