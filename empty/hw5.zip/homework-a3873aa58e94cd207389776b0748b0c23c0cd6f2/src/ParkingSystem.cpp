//
// Created by 黃漢軒 on 2023/11/22.
//

#include "ParkingSystem.hpp"

int ParkingSystem::FindVehicleIndexByPlateNumber(std::string plateNumber){
    return 0;
}

int ParkingSystem::GetChargingFeeByPlateNumber(std::string plateNumber){
    return 0;
}

ParkingSystem::ParkingSystem(){
}

void ParkingSystem::AddVehicle(std::shared_ptr<Vehicle> vehicle){
}

void ParkingSystem::RemoveVehicle(std::string plateNumber){
}

int ParkingSystem::GetTotalParkingPricePerHour() {
    return 0;
}

int ParkingSystem::CalculateParkingPrice(std::string plateNumber, int hour){
    return 0;
}

int ParkingSystem::GetSize(){
    return 0;
}