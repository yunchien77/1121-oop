//
// Created by Uriah Xuan on 10/16/2023.
//

#ifndef OOP_ELECTRICBUS_HPP
#define OOP_ELECTRICBUS_HPP

#include "Bus.hpp"

class ElectricBus { // You may need to do some inheritance here.
private:
    /* Define the private member here */
public:
    /* Define the public member here */
};

#endif // OOP_ELECTRICBUS_HPP
