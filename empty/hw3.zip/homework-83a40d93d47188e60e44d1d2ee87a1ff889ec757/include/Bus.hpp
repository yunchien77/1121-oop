//
// Created by Uriah Xuan on 10/16/2023.
//

#ifndef OOP_BUS_HPP
#define OOP_BUS_HPP

#include <string>
#include <vector>

class Bus {
private:
    /* Define the private member here */
public:
    /* Define the public member here */
};

#endif // OOP_BUS_HPP
