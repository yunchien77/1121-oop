//
// Created by 黃漢軒 on 2023/10/21.
//

#ifndef OOP_MAGLEVBUS_HPP
#define OOP_MAGLEVBUS_HPP

#include "Bus.hpp"

class MaglevBus { // You may need to do some inheritance here.
private:
    /* Define the private member here */
public:
    /* Define the public member here */
};

#endif // OOP_MAGLEVBUS_HPP
